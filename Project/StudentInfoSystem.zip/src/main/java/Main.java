import java.io.IOException;

/**
 * @Author: Cho
 * @Date: 2022/05/12/0:30
 * @Description: the main class of Student Information System
 */
public class Main {
    public static void main(String[] args) throws InterruptedException, IOException {
        SystemMenu test = new SystemMenu();
        test.welcomeMenu();
    }
}
