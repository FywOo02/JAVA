package exit;

import place.Place;

public class Door extends Exit {

	/**
	 * 
	 * @param P1 the first place it give access to
	 * @param P2 the seacond place it give access to
	 */
	public Door(Place P1, Place P2) {
		super(P1, P2);
	}

}
