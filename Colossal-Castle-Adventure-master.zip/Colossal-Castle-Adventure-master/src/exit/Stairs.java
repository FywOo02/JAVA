package exit;

import place.Place;

public class Stairs extends Exit {

	/**
	 * 
	 * @param P1 the first place it give access to
	 * @param P2 the second place it give access to
	 */
	public Stairs(Place P1, Place P2) {
            super(P1, P2);
	}
}
