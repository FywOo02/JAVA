package items;

public class TresorKey extends TrunkKey {

    /**
     * 
     * @param name name of the key
     * @param description description of the key
     */
    public TresorKey(String name, String description) {
        super(name, description);
    }

}