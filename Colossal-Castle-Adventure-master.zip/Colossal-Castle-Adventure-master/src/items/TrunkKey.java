package items;

public class TrunkKey extends Key {

    /**
     * 
     * @param name name of the key
     * @param description description of the key
     */
    public TrunkKey(String name, String description) {
        super(name, description);
    }
}