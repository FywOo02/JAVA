package items;

public class DoorKey extends Key {

    /**
     *
     * @param name name of the key
     * @param description description of the key
     */
    public DoorKey(String name, String description) {
        super(name, description);
    }
}