package game;
/**
 * CommandFunction
 */
public interface CommandFunction {
    void runCommand(Game g,String[] args);
} 