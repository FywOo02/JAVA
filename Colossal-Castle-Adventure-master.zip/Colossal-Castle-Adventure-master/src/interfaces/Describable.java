package interfaces;

public interface Describable {

	String DESCRIPTION = "";

	/**
	 * 
	 * @return the description of the object
	 */
	String readDescription();

}