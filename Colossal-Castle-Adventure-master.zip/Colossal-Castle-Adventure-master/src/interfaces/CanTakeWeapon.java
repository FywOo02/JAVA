package interfaces;
import items.Weapon; 

public interface CanTakeWeapon {

    abstract public void switchWeapon(Weapon w); 
} 

