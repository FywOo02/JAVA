package interfaces;
/**
 * this interface is used for all the class 
 * that can take an item
 */
public interface CanTakeItem {
    
}
