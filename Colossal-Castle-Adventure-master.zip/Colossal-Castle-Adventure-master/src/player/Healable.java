package player;

/**
 *
 * @author mziar01
 */
public interface Healable {
    
    /**
     *
     * @param nbHp
     */
    abstract public void heal(int nbHp);
    
}
