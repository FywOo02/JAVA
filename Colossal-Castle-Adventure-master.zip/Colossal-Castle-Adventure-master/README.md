# Colossal-Castle-Adventure
A little adventure game inspired by colossal cave adventure

# To play
In the main folder use this command : 
cd build/classes;java main/Main
